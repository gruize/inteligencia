package conector.util.exceptions;

/**
 * 
 * Excepcion de archivo con formato incorrecto
 * 
 * @author Kenzitron
 *
 */

public class BadFormattedFile extends Exception {
	
	private static final long serialVersionUID = 5028225150425632794L;

}
