package conector.util.exceptions;

public class BadUniFileException extends Exception {

	/**
	 * 
	 * Excepcion que se produce cuando un fichero de Universo
	 * no tiene el formato correcto.
	 * 
	 */
	
	private static final long serialVersionUID = 8557464861433700439L;

}
