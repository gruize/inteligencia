package juegos.BlancasNegras;

/**
 * Tipos de fichas
 * @author Grupo C15
 */
public enum Fichas {Blanca,Negra,Vacia}
