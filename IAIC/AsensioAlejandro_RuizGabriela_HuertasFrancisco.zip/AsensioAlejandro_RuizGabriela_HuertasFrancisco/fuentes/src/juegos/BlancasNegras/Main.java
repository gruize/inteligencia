package juegos.BlancasNegras;

/**
 * @author Grupo C15
 */
public class Main {
    
    public static void main(String[] args) {
        BlancasNegras nuevo = new BlancasNegras();
        nuevo.ejecutar();
    }
    
}
