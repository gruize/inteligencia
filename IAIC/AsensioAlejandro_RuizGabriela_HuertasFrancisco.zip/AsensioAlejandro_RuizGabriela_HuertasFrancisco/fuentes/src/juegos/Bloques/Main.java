package juegos.Bloques;

public class Main {

	public static void main(String[] args) {
		Bloques nuevo = new Bloques();
		nuevo.ejecutar();
	}

}
