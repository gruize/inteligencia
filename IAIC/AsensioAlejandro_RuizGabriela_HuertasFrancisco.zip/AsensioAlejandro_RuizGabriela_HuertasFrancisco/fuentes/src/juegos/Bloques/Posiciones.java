package juegos.Bloques;

/**
 * Posiciones de los bloques
 * @author Grupo C15
 */
public enum Posiciones {
	A, B, C, mesa
}
