package juegos.CajaColores;

/**
 * Posibles colores
 * @author Grupo C15
 */
public enum Colores {Rojo,Azul}