package juegos.CajaColores;
/**
 *
 * @author Grupo C15
 */
public class Main {

    public static void main(String[] args) {
        CajaDeColores nuevo = new CajaDeColores();
        nuevo.ejecutar();
    }

}
