package juegos.Canibal;

/**
 *
 * @author Grupo C15
 */

public class Main {
    
    public static void main(String[] args) throws Exception {
        Misionero nuevo = new Misionero();
        nuevo.ejecutar();
    }

}