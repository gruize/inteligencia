package juegos.Garrafas;

/**
 *
 * @author Grupo C15
 */
public class Main {

    public static void main(String[] args) {
        Garrafas nuevo = new Garrafas();
        nuevo.ejecutar();
    }

}
