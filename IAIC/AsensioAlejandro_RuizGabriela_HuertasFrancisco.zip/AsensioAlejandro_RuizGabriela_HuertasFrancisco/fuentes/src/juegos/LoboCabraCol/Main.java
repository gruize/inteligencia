package juegos.LoboCabraCol;

public class Main {
	public static void main(String[] args) {
        LCC nuevo = new LCC();
        nuevo.ejecutar();
	}
	
}