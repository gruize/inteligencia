package juegos.Mono;

public class Main {

	public static void main(String[] args) {
		Mono nuevo = new Mono();
		nuevo.ejecutar();
	}

}
