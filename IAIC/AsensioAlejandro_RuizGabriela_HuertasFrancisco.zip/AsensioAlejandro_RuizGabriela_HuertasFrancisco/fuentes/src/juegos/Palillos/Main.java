package juegos.Palillos;

public class Main {

	public static void main(String[] args) {
		Palillos nuevo = new Palillos();
		nuevo.ejecutar();
	}

}
