package juegos.Pollos;

/**
 *
 * @author Grupo C15
 */
public class Main {

    public static void main(String[] args) {
        Pollos nuevo = new Pollos();
        nuevo.ejecutar();
    }    
    
}
