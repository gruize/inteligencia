package juegos.Pollos;

/**
 * Blanco --> Azul --> Rojo --> Pollito (Fin)
 * @author Grupo C15
 */
public enum Valores {Pollito,Rojo,Azul,Blanco}
