package juegos.Puzzle;

/**
 *
 * @author Grupo C15
 */
public class Main {

    public static void main(String[] args) {
        Puzzle nuevo = new Puzzle();
        nuevo.ejecutar();
    }    
    
}
