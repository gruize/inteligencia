package juegos.Robot;

/**
 *
 * @author Grupo C15
 */
public class Main {

    public static void main(String[] args) {
        Robot nuevo = new Robot();
        nuevo.ejecutar();
    }
        
}
