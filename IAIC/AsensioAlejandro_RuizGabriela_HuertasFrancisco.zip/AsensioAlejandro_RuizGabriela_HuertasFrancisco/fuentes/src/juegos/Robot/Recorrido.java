package juegos.Robot;

/**
 * Posibles valores de las casillas
 * @author Grupo C15
 */
public enum Recorrido {Muro, Camino, Robot}

